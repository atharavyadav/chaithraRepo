package resusableComponents;

public interface reausableData {

	public static String chromedriverType="webdriver.chrome.driver";
	public static String edgedriverType="webdriver.edge.driver";
	public static String browserType="edge";
	public static String chromedriverPath="D:\\eclipse\\POMProject\\driver\\chromedriver.exe";
	public static String EdgeDriverPath="D:\\eclipse\\RedBus\\Browser\\msedgedriver.exe";
	public static String URL="https://demo.guru99.com/test/newtours/register.php";
	
}

package resusableComponents;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class filereader {
	public static String ReadDatafromfile(String keyname) throws IOException
	{
		File file = new File("D:\\eclipse\\POMProject\\src\\test\\resources\\testdata\\testdata.properties");
	    FileInputStream stream = new FileInputStream(file);
	    Properties prop = new Properties();
	    prop.load(stream);
	    String data = prop.getProperty(keyname);
	    return data;
	
	}

}

package driverdetails;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import resusableComponents.reausableData;

public class intiliazeSeleniumBrowser {

	public static WebDriver driver;
	public static void readDriverDetails(String url)
	{
		String browserType="chrome";
		
		if(browserType==reausableData.browserType)
		{
			System.setProperty(reausableData.chromedriverType,reausableData.chromedriverPath);
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(url);
		}
			
		else
		{
			System.setProperty(reausableData.edgedriverType,reausableData.EdgeDriverPath);
			driver = new EdgeDriver();
			driver.manage().window().maximize();
			driver.get(url);
		}
	}
}

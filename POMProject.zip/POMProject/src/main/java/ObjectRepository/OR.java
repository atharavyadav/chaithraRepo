package ObjectRepository;

public interface OR {
	public static String FirstName_Xpath="//input[@name='firstName']";
	public static String lastName_Xpath="//input[@name='lastName']";
	public static String phone_Xpath="//input[@name='phone']";
	public static String Home_Xpath="//a[text()='Home']";

}

package seleniumUIActions;

import java.io.IOException;

import org.openqa.selenium.By;

import ObjectRepository.OR;
import driverdetails.intiliazeSeleniumBrowser;
import resusableComponents.filereader;

public class seleniumActions {
	
	public static void EnterContactInormation() throws IOException
	{
		intiliazeSeleniumBrowser.driver.findElement(By.xpath(OR.FirstName_Xpath)).sendKeys(filereader.ReadDatafromfile("Firstname"));
		intiliazeSeleniumBrowser.driver.findElement(By.xpath(OR.lastName_Xpath)).sendKeys(filereader.ReadDatafromfile("lastname"));
		intiliazeSeleniumBrowser.driver.findElement(By.xpath(OR.phone_Xpath)).sendKeys(filereader.ReadDatafromfile("phonenumber"));
	}
	public static void clickonhomePage() throws IOException
	{
		intiliazeSeleniumBrowser.driver.findElement(By.xpath(OR.Home_Xpath)).click();
		
	}
}
